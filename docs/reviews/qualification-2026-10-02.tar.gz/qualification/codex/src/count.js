function isPositiveCount(value) {
  return Number.isInteger(value) && value >= 1 && value <= 100;
}

module.exports = { isPositiveCount };
