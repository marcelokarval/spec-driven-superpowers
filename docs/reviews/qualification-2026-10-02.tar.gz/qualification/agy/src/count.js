/**
 * Validates whether a value is a positive integer between 1 and 100 inclusive.
 * Rejects strings, non-numbers, non-integers, NaN, and Infinity.
 *
 * @param {unknown} value
 * @returns {boolean}
 */
function isPositiveCount(value) {
  if (typeof value !== 'number') {
    return false;
  }
  if (!Number.isInteger(value)) {
    return false;
  }
  return value >= 1 && value <= 100;
}

module.exports = {
  isPositiveCount,
};
