# count

## ADDED Requirements

### Requirement: Positive integer predicate
O módulo count MUST fornecer o comportamento público abaixo por export nomeado CommonJS.

#### Scenario: Valid counts
- **WHEN** value é 1, 2, 99 ou 100
- **THEN** isPositiveCount(value) SHALL retornar true.

### Requirement: Reject invalid counts
O módulo count MUST fornecer o comportamento público abaixo por export nomeado CommonJS.

#### Scenario: Invalid counts
- **WHEN** value é 0, -1, 101, 999, 1000, 1001, 1.5, "2", "", NaN, Infinity, -Infinity, null, undefined, true, false, {}, [], 1n, Symbol() ou new Number(2)
- **THEN** isPositiveCount(value) SHALL retornar false sem coerção e sem lançar erro.

