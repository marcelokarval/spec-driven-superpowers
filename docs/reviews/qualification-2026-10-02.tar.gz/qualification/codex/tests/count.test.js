const test = require('node:test');
const assert = require('node:assert/strict');
const { isPositiveCount } = require('../src/count');

test('exports isPositiveCount as a named CommonJS function', () => {
  assert.equal(typeof isPositiveCount, 'function');
});

for (const value of [1, 2, 99, 100]) {
  test(`accepts integer count ${value}`, () => {
    assert.equal(isPositiveCount(value), true);
  });
}

const invalidCounts = [
  ['zero', 0], ['negative', -1], ['above maximum (101)', 101],
  ['former valid count 999', 999], ['former maximum 1000', 1000],
  ['above former maximum (1001)', 1001],
  ['fraction', 1.5], ['numeric string', '2'], ['empty string', ''],
  ['NaN', NaN], ['Infinity', Infinity], ['-Infinity', -Infinity],
  ['null', null], ['undefined', undefined], ['true', true], ['false', false],
  ['object', {}], ['array', []], ['bigint', 1n], ['symbol', Symbol()],
  ['boxed number', new Number(2)],
];

for (const [name, value] of invalidCounts) {
  test(`rejects ${name} without coercion or throwing`, () => {
    assert.equal(isPositiveCount(value), false);
  });
}
