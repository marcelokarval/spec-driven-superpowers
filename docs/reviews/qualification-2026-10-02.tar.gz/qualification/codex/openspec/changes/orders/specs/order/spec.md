# order

## ADDED Requirements

### Requirement: Sum valid quantities
O módulo order MUST fornecer o comportamento público abaixo por export nomeado CommonJS.

#### Scenario: Valid totals
- **WHEN** items é [], [{ quantity: 2 }], quantidades [1, 2, 100] ou [100, 100]
- **THEN** totalUnits(items) SHALL retornar respectivamente 0, 2, 103 ou 200 usando isPositiveCount.

### Requirement: Reject invalid orders
O módulo order MUST fornecer o comportamento público abaixo por export nomeado CommonJS.

#### Scenario: Invalid orders
- **WHEN** items não é array, ou contém null, undefined, primitivo, array como item, objeto sem quantity, posição vazia ou quantity inválida conforme count/Invalid counts (incluindo 101, 999 e 1000)
- **THEN** totalUnits(items) SHALL lançar TypeError.

### Requirement: Reject without partial result
O módulo order MUST fornecer o comportamento público abaixo por export nomeado CommonJS.

#### Scenario: Atomic rejection
- **WHEN** um item com quantity 101 aparece no início, meio ou fim entre itens de quantity 1
- **THEN** totalUnits(items) SHALL lançar TypeError sem retornar soma parcial.

