const test = require('node:test');
const assert = require('node:assert/strict');
const { orderLabel } = require('../src/label');

test('exports orderLabel as a named CommonJS function', () => {
  assert.equal(typeof orderLabel, 'function');
});

for (const [id, expected] of [
  ['abc', 'ORDER:abc'],
  ['  Ab-12 \n', 'ORDER:Ab-12'],
  ['a b', 'ORDER:a b'],
]) {
  test(`formats ${JSON.stringify(id)} independently of an order`, () => {
    assert.equal(orderLabel(id), expected);
  });
}

const invalidIds = [
  ['empty string', ''], ['spaces', '   '], ['tabs and newlines', '\t\n\r'],
  ['number', 2], ['true', true], ['false', false], ['null', null],
  ['undefined', undefined], ['object', {}], ['array', []],
  ['symbol', Symbol()], ['bigint', 1n], ['boxed string', new String('abc')],
];

for (const [name, id] of invalidIds) {
  test(`rejects ${name} with TypeError`, () => {
    assert.throws(() => orderLabel(id), TypeError);
  });
}
