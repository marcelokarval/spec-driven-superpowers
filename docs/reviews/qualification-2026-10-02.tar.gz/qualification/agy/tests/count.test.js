const test = require('node:test');
const assert = require('node:assert/strict');
const { isPositiveCount } = require('../src/count.js');

test('count: Accept positive integer in range', () => {
  assert.equal(isPositiveCount(1), true);
  assert.equal(isPositiveCount(50), true);
  assert.equal(isPositiveCount(100), true);
});

test('count: Reject zero and negative integers', () => {
  assert.equal(isPositiveCount(0), false);
  assert.equal(isPositiveCount(-1), false);
  assert.equal(isPositiveCount(-500), false);
});

test('count: Reject integers above 100', () => {
  assert.equal(isPositiveCount(101), false);
  assert.equal(isPositiveCount(1000), false);
  assert.equal(isPositiveCount(10000), false);
});

test('count: Reject non-integers and special numbers', () => {
  assert.equal(isPositiveCount(1.5), false);
  assert.equal(isPositiveCount(0.1), false);
  assert.equal(isPositiveCount(NaN), false);
  assert.equal(isPositiveCount(Infinity), false);
  assert.equal(isPositiveCount(-Infinity), false);
});

test('count: Reject non-number types', () => {
  assert.equal(isPositiveCount('1'), false);
  assert.equal(isPositiveCount('100'), false);
  assert.equal(isPositiveCount(true), false);
  assert.equal(isPositiveCount(false), false);
  assert.equal(isPositiveCount(null), false);
  assert.equal(isPositiveCount(undefined), false);
  assert.equal(isPositiveCount({}), false);
  assert.equal(isPositiveCount([]), false);
  assert.equal(isPositiveCount(Symbol('test')), false);
  assert.equal(isPositiveCount(10n), false);
});
