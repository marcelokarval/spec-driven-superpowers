const { isPositiveCount } = require('./count');

function totalUnits(items) {
  if (!Array.isArray(items)) {
    throw new TypeError('Order items must be an array');
  }

  let total = 0;
  for (const item of items) {
    if (item === null || typeof item !== 'object' || Array.isArray(item)) {
      throw new TypeError('Order item must be an object');
    }

    const quantity = item.quantity;
    if (!isPositiveCount(quantity)) {
      throw new TypeError('Order item quantity must be a valid count');
    }
    total += quantity;
  }

  return total;
}

module.exports = { totalUnits };
