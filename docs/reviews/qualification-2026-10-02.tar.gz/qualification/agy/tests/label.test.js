const test = require('node:test');
const assert = require('node:assert/strict');
const { orderLabel } = require('../src/label.js');

test('label: Format valid identifier with ORDER prefix', () => {
  assert.equal(orderLabel('123'), 'ORDER:123');
  assert.equal(orderLabel('ABC-99'), 'ORDER:ABC-99');
  assert.equal(orderLabel('order_id_1'), 'ORDER:order_id_1');
});

test('label: Trim whitespace around identifier', () => {
  assert.equal(orderLabel('  123  '), 'ORDER:123');
  assert.equal(orderLabel('\tABC-99\n'), 'ORDER:ABC-99');
  assert.equal(orderLabel('  order_id_1 '), 'ORDER:order_id_1');
});

test('label: Reject non-string or blank identifier with TypeError', () => {
  assert.throws(() => orderLabel(''), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel('   '), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel('\t\n'), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel(null), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel(undefined), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel(123), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel(true), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel({}), {
    name: 'TypeError',
  });
  assert.throws(() => orderLabel(['123']), {
    name: 'TypeError',
  });
});
