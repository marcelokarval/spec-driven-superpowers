# Proposal: Order Pilot CommonJS Library

## Why
Evolve the order pilot repository into a zero-dependency CommonJS library providing reliable positive integer validation, atomic order item quantity summation, and isolated textual label formatting for downstream components.

## What Changes
- Add `src/count.js` exporting `isPositiveCount` to validate positive integers between 1 and 100 inclusive.
- Add `src/order.js` exporting `totalUnits` to sum item quantities using `isPositiveCount` validation, rejecting item quantities above 100 while permitting total sums above 100 when each item is valid.
- Add `src/label.js` exporting `orderLabel` to format order identifiers with `ORDER:<id>` prefix, completely decoupled from summation.
- Add unit tests for each module in `tests/count.test.js`, `tests/order.test.js`, and `tests/label.test.js` using Node.js built-in `node:test` runner.
- Maintain `package.json` and `tests/baseline.test.js` completely intact.

## Capabilities
### New Capabilities
- `count`: Validate whether a value is a positive integer strictly within [1, 100].
- `order`: Calculate total units across order items with atomic validation, rejecting items above 100 while allowing totals above 100.
- `label`: Format textual order labels from non-empty string identifiers with trimming.

### Modified Capabilities
None.

## Impact
- New modules in `src/`: `src/count.js`, `src/order.js`, `src/label.js`.
- New tests in `tests/`: `tests/count.test.js`, `tests/order.test.js`, `tests/label.test.js`.
- Existing files `package.json` and `tests/baseline.test.js` remain preserved and untouched.
- Zero external runtime or development dependencies added.

## Understanding
- Current repository is an empty fixture with baseline test passing on Node.js built-in test runner.
- The library must use CommonJS (`module.exports`) and named exports.
- Quantities must be numbers, integers, and within [1, 100], rejecting strings, NaN, Infinity, floats, and non-numbers.
- Summation accepts array of `{ quantity }` objects, returns 0 for empty array, and throws TypeError for any invalid input without returning partial sums. Individual item quantities above 100 are rejected, but total sums exceeding 100 are permitted when all items are valid.
- Label formatting is purely textual and independent from items or quantities.

## Open questions
None. All material decisions were answered and recorded in design.md.
