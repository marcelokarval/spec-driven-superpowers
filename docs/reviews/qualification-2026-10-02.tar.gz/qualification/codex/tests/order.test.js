const test = require('node:test');
const assert = require('node:assert/strict');
const { totalUnits } = require('../src/order');

test('exports totalUnits as a named CommonJS function', () => {
  assert.equal(typeof totalUnits, 'function');
});

for (const [quantities, expected] of [
  [[], 0], [[2], 2], [[1, 2, 100], 103], [[100, 100], 200],
]) {
  test(`sums ${JSON.stringify(quantities)} to ${expected}`, () => {
    assert.equal(totalUnits(quantities.map(quantity => ({ quantity }))), expected);
  });
}

const nonArrays = [
  ['undefined', undefined], ['null', null], ['number', 2], ['string', '2'],
  ['boolean', true], ['object', {}], ['array-like', { 0: { quantity: 1 }, length: 1 }],
  ['bigint', 1n], ['symbol', Symbol()], ['function', () => {}],
];

for (const [name, input] of nonArrays) {
  test(`rejects non-array input: ${name}`, () => {
    assert.throws(() => totalUnits(input), TypeError);
  });
}

const invalidItems = [
  ['null', null], ['undefined', undefined], ['number', 2], ['string', '2'],
  ['boolean', false], ['bigint', 1n], ['symbol', Symbol()],
  ['array with quantity', Object.assign([], { quantity: 1 })],
  ['function with quantity', Object.assign(() => {}, { quantity: 1 })],
  ['missing quantity', {}],
];

for (const [name, item] of invalidItems) {
  test(`rejects invalid item: ${name}`, () => {
    assert.throws(() => totalUnits([item]), TypeError);
  });
}

test('rejects a sparse array slot instead of skipping it', () => {
  assert.throws(() => totalUnits([{ quantity: 1 }, , { quantity: 1 }]), TypeError);
});

const invalidQuantities = [
  ['zero', 0], ['negative', -1], ['101', 101], ['999', 999], ['1000', 1000],
  ['1001', 1001], ['fraction', 1.5], ['numeric string', '2'], ['empty string', ''],
  ['NaN', NaN], ['Infinity', Infinity], ['-Infinity', -Infinity],
  ['null', null], ['undefined', undefined], ['true', true], ['false', false],
  ['object', {}], ['array', []], ['bigint', 1n], ['symbol', Symbol()],
  ['boxed number', new Number(2)],
];

for (const [name, quantity] of invalidQuantities) {
  test(`rejects invalid quantity: ${name}`, () => {
    assert.throws(() => totalUnits([{ quantity }]), TypeError);
  });
}

for (const index of [0, 1, 2]) {
  test(`throws without returning a partial total when item ${index} is invalid`, () => {
    const items = [{ quantity: 1 }, { quantity: 1 }, { quantity: 1 }];
    items[index].quantity = 101;
    assert.throws(() => totalUnits(items), TypeError);
  });
}
