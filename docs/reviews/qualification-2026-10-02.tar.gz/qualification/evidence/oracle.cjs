const test=require('node:test');const assert=require('node:assert/strict');const path=require('node:path');
const root=process.env.ASDS_PILOT_ROOT;const max=Number(process.env.ASDS_PILOT_MAX||1000);
const {isPositiveCount}=require(path.join(root,'src/count.js'));
const {totalUnits}=require(path.join(root,'src/order.js'));
const {orderLabel}=require(path.join(root,'src/label.js'));
test('quantity positive bounds and no coercion',()=>{for(const x of [1,2,max])assert.equal(isPositiveCount(x),true);for(const x of [0,-1,max+1,1.5,'2',NaN,Infinity,null,undefined,{},[],true,2n])assert.equal(isPositiveCount(x),false);});
test('sum and empty; shared bound',()=>{assert.equal(totalUnits([]),0);assert.equal(totalUnits([{quantity:1},{quantity:max}]),max+1);assert.equal(totalUnits([{quantity:max},{quantity:max}]),2*max);});
test('invalid container and items fail atomically',()=>{for(const x of [null,{},'x',3])assert.throws(()=>totalUnits(x),TypeError);for(const item of [null,{},3,{quantity:'3'},{quantity:0},{quantity:max+1}])assert.throws(()=>totalUnits([{quantity:2},item,{quantity:1}]),TypeError);assert.throws(()=>totalUnits(new Array(1)),TypeError);});
test('label trims independently',()=>{assert.equal(orderLabel('  Ab 1  '),'ORDER:Ab 1');for(const x of ['', '  ',null,undefined,3,{},[]])assert.throws(()=>orderLabel(x),TypeError);});

test('validated quantity is the quantity summed',()=>{let reads=0; const item={get quantity(){return ++reads===1?2:Infinity;}}; assert.equal(totalUnits([item]),2); assert.equal(reads,1);});
