# Design: Order Pilot CommonJS Library

## Context
The project `/tmp/asds-qualification-5btv_iwl/agy` is a lightweight qualification fixture running on Node.js v24.20.0 with a built-in test runner (`node:test`) and no external dependencies. The goal is to provide three core interfaces consumable by downstream order processing components: positive integer count validation (`src/count.js`), order unit summation (`src/order.js`), and order label formatting (`src/label.js`).

## Goals / Non-Goals
### Goals
- Implement `isPositiveCount` in `src/count.js` as a pure predicate validating integer counts in the closed interval [1, 100].
- Implement `totalUnits` in `src/order.js` to sum quantities from `{ quantity }` objects using `isPositiveCount`, rejecting item quantities above 100 while permitting total sums above 100 when each item is valid, returning 0 for empty array and throwing `TypeError` atomically on any invalid input.
- Implement `orderLabel` in `src/label.js` to format non-empty strings into `ORDER:<id-trimmed>`, throwing `TypeError` for non-strings or blank strings.
- Provide comprehensive unit tests in `tests/count.test.js`, `tests/order.test.js`, and `tests/label.test.js` using `node:test` and `node:assert/strict`.
- Preserve `package.json` and `tests/baseline.test.js` without modification.

### Non-Goals
- Adding external npm runtime or development dependencies.
- Supporting quantities outside [1, 100] or non-numeric string coercion.
- Partial summation or error aggregation when invalid items are encountered.
- Coupling label formatting with order item calculations.

## Architecture Decisions
1. **Module Format**: Standard CommonJS (`module.exports = { ... }`) with explicit named exports:
   - `src/count.js`: `{ isPositiveCount }`
   - `src/order.js`: `{ totalUnits }`
   - `src/label.js`: `{ orderLabel }`
2. **Atomic Validation**: `totalUnits` fails fast by throwing `TypeError` immediately upon encountering a non-array, an invalid item structure, or an invalid `quantity`. No partial calculation or warning accumulator is returned.
3. **Decoupling**: `src/label.js` operates solely on identifier strings, maintaining zero dependency on `src/count.js` or `src/order.js`.
4. **Dependency Direction**: `src/order.js` depends on `src/count.js`. `src/count.js` and `src/label.js` have zero internal dependencies.

## Security & Performance Considerations
- Input validation strictly enforces numeric integer type within the closed interval [1, 100], rejecting unexpected types, `NaN`, and `Infinity`.
- Item summation operates with $O(N)$ linear time complexity where $N$ is the number of items, performing fast-fail validation on each item.

## Decisions and authorization
- **Framework & Standard**: ASDS (Autonomous Spec-Driven Superpowers) explicitly selected.
- **Continuity and Decisions Preserved**:
  - Material change: Maximum quantity per item revised from 1000 to 100 inclusive. Individual items with quantity exceeding 100 are rejected with `TypeError`; total order sums exceeding 100 remain valid when all individual items are in [1, 100].
  - `isPositiveCount`: Rejects strings, `NaN`, `Infinity`, fractions, $\le 0$, and $> 100$.
  - `totalUnits`: Accepts array of objects with `quantity`, returns 0 for `[]`, throws `TypeError` for non-array or any invalid item/quantity.
  - `orderLabel`: Byte-for-byte preserved; trims input, requires non-empty string, returns `ORDER:<trimmed>`, throws `TypeError` otherwise.
  - Test layout: `tests/<nome>.test.js`, keeping `package.json` and `tests/baseline.test.js` intact.
- **Authorization Scope**:
  - Task 0001 reopened in `tasks.md` due to material bound change.
  - Task 0002 updated to reflect the new item boundary and total sum allowance.
  - Task 0003 preserved without reimplementation.
  - Code/test changes are not yet authorized. Review and integration processes will be conducted by the coordinator.

## Dependency and verification strategy
- **Foundation Phase**:
  - Task 0001 (`src/count.js` and `tests/count.test.js`): Independent. Verified with `node --test tests/count.test.js`.
  - Task 0003 (`src/label.js` and `tests/label.test.js`): Independent. Verified with `node --test tests/label.test.js`.
- **Dependent Phase**:
  - Task 0002 (`src/order.js` and `tests/order.test.js`): Depends on Task 0001. Verified with `node --test tests/order.test.js`.
- **Integration Gate**:
  - Verification of the full suite with `node --test` covering all test files including `tests/baseline.test.js`.
