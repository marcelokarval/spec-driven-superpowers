# Design — orders

## Context and goals
Projeto: /tmp/asds-qualification-5btv_iwl/codex. ASDS explicitamente selecionado pelo
usuário; esta mudança substitui o plano conversacional como fonte de planejamento.
Objetivo: três interfaces CommonJS, sem dependências externas, com testes node:test
separados por módulo. O único índice de progresso é tasks.md.

## Decisions and architecture
Decisões do usuário preservadas: exports nomeados isPositiveCount, totalUnits e
orderLabel nos módulos count.js, order.js e label.js, respectivamente.
isPositiveCount(value) retorna booleano: somente número inteiro entre 1 e 100
inclusive é válido, sem coerção. Strings, NaN e Infinity são inválidos.
totalUnits(items) recebe array de objetos não nulos e não arrays com quantity válida;
usa isPositiveCount, retorna 0 para vazio e soma numérica caso todos sejam válidos.
Não-array, item inválido, posição vazia ou quantity inválida lança TypeError,
sem retornar resultado parcial. O limite 100 é por item, não por soma.
orderLabel(id) aceita apenas string primitiva não vazia após trim e retorna
ORDER:<id-trimmed>. Preserva caixa e espaços internos. Demais entradas lançam
TypeError. Não importa count ou order. Mensagens de erro não são contrato público.
A decisão material atual do usuário reduz o limite anterior de 1000 para 100;
assinaturas, rejeição por TypeError em order e contrato de label permanecem.
Quantidades 101, 999 e 1000 passam a ser inválidas; [100, 100] deve somar 200.

## Dependencies and resources
0002 depende de 0001; 0003 é independente. Sem recursos externos compartilhados.
Futuras tarefas escrevem somente seus src/<nome>.js e tests/<nome>.test.js.
package.json e tests/baseline.test.js são recursos preservados, somente leitura.
Sem tarefa adicional de integração: revisão, integração, npm test final e checkoff
pertencem ao coordenador depois, com evidência vinculada à revisão correspondente.

## Scope and evidence boundaries
Nenhuma instalação, cópia de skills, worktree, backup, serviço ou configuração global.
A ausência de coerção é um requisito comportamental de count. Este piloto não
demonstra garantias gerais de segurança, isolamento ou ausência de execução de
código por entradas arbitrárias; tais garantias não são afirmadas pelo design.
Sem código/testes nesta etapa. Sem agregador, dependências ou publicação.

## Session and authority — registro da etapa inicial
Harness observado: Codex via API; versão do harness não consultada. Node observado:
v24.20.0. Leitura/escrita local e shell disponíveis; shell não-login funciona.
Skill lida em /home/marcelo-karval/.agents/skills/spec-driven-superpowers/SKILL.md,
com intake, activation, protocol, capabilities, planning, contracts e adapter Codex.
Toolkit existente: /home/marcelo-karval/Backup/Projetos/spec-driven-superpowers,
package version 1.1.0, OpenSpec fixado em 1.14.0. Nada instalado ou copiado.
Schema global existente observado em ~/.local/share/openspec/schemas/superpowers-bridge;
config local seleciona esse nome. Workspace original, sem isolamento adicional.
Paralelismo autorizado: nenhum; delegação expressamente proibida.
Autorização vigente: criar openspec/ e artefatos da única mudança orders e validar
planejamento. Código, testes, commit, push e delegação permanecem não autorizados.
Revisores e integração serão providos pelo coordenador, sem aprovação independente
nesta etapa. Prontidão estrutural não constitui autorização de execução.

## Baseline and continuity — registro da etapa inicial
Base observada antes da escrita: f588ccc2d3a3e304dfa3126961defb083177bd63;
git status --short sem alterações. Essa observação não é aprovação de base de entrega.
SHA256 package.json: 866af3cde8ac343638609ec5e78ad28eabbb15786c493296b837bc718d5ab95f.
SHA256 tests/baseline.test.js: bad4f1d008f8facb1c71306f73eeba60806521e3a6d200797f172498a53e4136.
Retomar por proposal.md, este design, specs/*/spec.md, tasks/task-*.md e tasks.md.
Preservar decisões/autorizações, sem repetir intake ou inicialização. Antes de executar,
o coordenador precisa de autorização para código/testes, registrar base e aceitar as
contractRevision retornadas por loadTasks no contexto final. Não gravar hashes de
contrato neste design: ele participa da identidade calculada.
Testes baseline/funcionais não executados nesta etapa. Na futura execução autorizada,
rodar baseline antes das mudanças, seguir RED/GREEN por tarefa e preservar evidências.
Somente agendar 0002 após o pré-requisito 0001 integrado. 0003 não depende deles.
O coordenador conduz revisões independentes de especificação/qualidade, integra,
reexecuta verificações e só então marca tasks.md com recibos adequados. Nenhum recibo
ou aprovação independente foi fabricado. Evidência de entrega futura deve ficar fora
do snapshot auditado ou em local ignorado aprovado pelo coordenador.

## Planning verification — resultados históricos da etapa inicial
Em 2026-10-02, os comandos abaixo passaram (exit code 0) no projeto:
- `node /home/marcelo-karval/Backup/Projetos/spec-driven-superpowers/scripts/validate.mjs --change /tmp/asds-qualification-5btv_iwl/codex/openspec/changes/orders`
  Resultado: ASDS validation passed; verificações estruturais, não certificação de testes/revisões.
- `/home/marcelo-karval/Backup/Projetos/spec-driven-superpowers/node_modules/.bin/openspec validate orders --type change --strict --no-interactive`
  Resultado: Change 'orders' is valid.
A avaliação própria do planejamento conferiu três contratos, três entradas abertas,
cobertura de todos os cenários, dependência 0002 -> 0001 e independência de 0003.
Não houve revisão independente. A preservação deve ser reconferida com os SHA256
acima no fechamento desta etapa. Os validadores serão reexecutados após este registro.
Próxima ação pertence ao coordenador: autorização de execução, aceitação das revisões
dos contratos e processos de revisão/integração posteriores. Não há execução funcional,
recibos de entrega ou integração. Encerrar aqui preserva a continuidade autorizada.


## Continuidade — mudança material do limite para 100
Retomada sobre HEAD 55e1eef8cdcafd31feae674b97093aea01e93141, checkout inicialmente limpo.
O usuário/coordenador informou testes em D e I, revisão independente de especificação
 e qualidade da primeira onda e reconciliação de 0001/0003; o índice observado confirma
ambas marcadas. Esses relatos anteriores não são novos recibos ou revisão deste delta.

Decisão e responsável: usuário, nesta retomada. Motivo: novo limite de negócio por
quantidade, de 1000 para 100 inclusive. Efeito: reavaliar semanticamente 0001 e sua
dependente 0002; reabrir somente 0001, mantendo 0002 aberta e 0003 marcada.
0002 deve rejeitar quantity acima de 100 com TypeError e aceitar total acima de 100
quando cada quantity for válida. Não alterar APIs nem comportamento de label.

Escopo atual autorizado: atualizar somente artefatos existentes de planejamento,
sem novos arquivos. Código/testes permanecem intactos, portanto count ainda implementa
o limite anterior até nova execução autorizada. O próximo ciclo TDD de 0001 deve
observar falha real nos casos 101/999/1000 antes de corrigir código. 0002 continua
aguardando revisão/integração da nova revisão de 0001. Sem commit/push/delegação/instalação.

Preservar byte a byte src/label.js, tests/label.test.js, specs/label/spec.md e
 tasks/task-0003.md. Não reimplementar 0003 nem repetir revisão de comportamento sem
novo motivo. Trabalho e revisão anteriores de label são preservados historicamente.

Identidade não equivale a impacto semântico: loadTasks inclui proposal/design/todas
as specs no hash de cada contrato. Assim, este delta invalida conservadoramente as
contractRevision de 0001, 0002 e também 0003, embora seu contrato próprio e código
não mudem. O coordenador reconciliará evidências de 0003 com o contexto atualizado;
não criar recibo, aprovação ou identidade de revisão fictícia para satisfazer validação.

Verificação desta retomada: executar ASDS estrutural e OpenSpec estrito no contexto
final. A tarefa 0003 marcada requer recibo integrado reconciliado no validador ASDS;
sem esse recibo, informar a pendência esperada em vez de desmarcar 0003 ou fabricar
prova. Resultados correntes serão devolvidos na conversa, sem novo artefato ou plano.
