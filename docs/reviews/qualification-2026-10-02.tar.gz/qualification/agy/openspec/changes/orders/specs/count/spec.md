# Specification: Count Validation

## Purpose
Provide a pure predicate function to validate whether a given value is a positive integer within allowable order item quantity bounds.

## ADDED Requirements

### Requirement: Positive Count Range Validation
The `isPositiveCount` function SHALL return `true` if and only if the input value is a JavaScript number, an integer, and falls within the closed range [1, 100]. It MUST return `false` for all other values.

#### Scenario: Accept positive integer in range
- **WHEN** the caller passes an integer between 1 and 100 inclusive
- **THEN** `isPositiveCount` returns `true`

#### Scenario: Reject zero and negative integers
- **WHEN** the caller passes 0 or a negative integer
- **THEN** `isPositiveCount` returns `false`

#### Scenario: Reject integers above 100
- **WHEN** the caller passes an integer strictly greater than 100
- **THEN** `isPositiveCount` returns `false`

#### Scenario: Reject non-integers and special numbers
- **WHEN** the caller passes a fractional number, `NaN`, `Infinity`, or `-Infinity`
- **THEN** `isPositiveCount` returns `false`

#### Scenario: Reject non-number types
- **WHEN** the caller passes a string, boolean, null, undefined, object, or symbol
- **THEN** `isPositiveCount` returns `false`
