# Specification: Order Unit Summation

## Purpose
Calculate the accumulated quantity of units across items in an order with strict atomic validation.

## ADDED Requirements

### Requirement: Order Unit Accumulation
The `totalUnits` function SHALL calculate the total sum of `quantity` across all items in an array of `{ quantity }` objects, delegating quantity validation to `isPositiveCount`. It MUST return 0 for an empty array and throw a `TypeError` for non-array input or any item with an invalid structure or quantity (including quantities exceeding 100). The function SHALL permit the total accumulated sum to exceed 100 when all individual items have valid quantities.

#### Scenario: Sum quantities of valid items
- **WHEN** the caller passes an array of objects each containing a valid `quantity` in [1, 100], even if the total sum exceeds 100
- **THEN** `totalUnits` returns the arithmetic sum of all item quantities

#### Scenario: Return zero for empty item array
- **WHEN** the caller passes an empty array `[]`
- **THEN** `totalUnits` returns 0

#### Scenario: Reject non-array input with TypeError
- **WHEN** the caller passes a non-array argument such as `null`, `undefined`, a number, or an object
- **THEN** `totalUnits` throws a `TypeError`

#### Scenario: Reject invalid items or quantities with TypeError atomically
- **WHEN** the caller passes an array containing an element that is null, not an object, missing `quantity`, or possessing an invalid `quantity` according to `isPositiveCount` (such as values strictly greater than 100)
- **THEN** `totalUnits` throws a `TypeError` without returning any partial total
