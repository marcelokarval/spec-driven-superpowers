# Orders — único índice de progresso

Somente o coordenador marca conclusão após revisão e integração comprovadas.
Planejamento validado não autoriza execução e não conclui tarefas funcionais.

- [x] [Task 0001](tasks/task-0001.md): Validar quantidades em count
- [x] [Task 0002](tasks/task-0002.md): Somar unidades em order usando count
- [x] [Task 0003](tasks/task-0003.md): Formatar identificação independente em label
