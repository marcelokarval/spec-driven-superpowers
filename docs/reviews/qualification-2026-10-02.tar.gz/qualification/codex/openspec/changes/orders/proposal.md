# Orders

## Why
Evoluir o fixture para uma biblioteca CommonJS de pedidos, sem dependências externas,
com interfaces verificáveis antes da integração. A inspeção encontrou src/ vazio,
package.json com node --test e somente tests/baseline.test.js, um assert.ok(true).

## What Changes
- Adicionar isPositiveCount em src/count.js e tests/count.test.js.
- Adicionar totalUnits em src/order.js e tests/order.test.js, reutilizando count.
- Adicionar orderLabel em src/label.js e tests/label.test.js, independente da soma.
- Nesta etapa produzir somente planejamento validado, sem código ou testes.

## Capabilities
### New Capabilities
- `count`: predicado de inteiros de 1 a 100.
- `order`: soma integral de quantidades válidas, rejeitando entradas inválidas.
- `label`: identificação textual com trim.
### Modified Capabilities
As assinaturas públicas permanecem. A mudança material reduz o limite de count
de 1000 para 100 e ajusta o consumidor order; label permanece preservado.

## Impact
Futura escrita limitada aos seis arquivos acima. package.json e baseline permanecem
intactos. Sem dependências, instalação, configuração global, commit, push ou delegação.
Sem agregador de exports, persistência, rede, preços ou publicação de pacote.

## Assumptions and open questions
Decisões materiais resolvidas pelo usuário nesta conversa. Não há perguntas abertas.
Nesta retomada somente a revisão documental de count/order está autorizada;
a primeira onda já foi executada e reconciliada pelo coordenador. Validar os artefatos não valida comportamento de código.
