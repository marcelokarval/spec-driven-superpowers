# Tasks: Order Pilot CommonJS Library

Only the coordinator updates this index after integration and verification.
Dependencies live in each linked contract; waves do not imply concurrency.

## Wave 1: Foundation and Independent Work
- [x] [Task 0001](tasks/task-0001.md): Implement and test count validation
- [x] [Task 0003](tasks/task-0003.md): Implement and test order label formatting

## Wave 2: Dependent Order Processing
- [x] [Task 0002](tasks/task-0002.md): Implement and test order unit summation
