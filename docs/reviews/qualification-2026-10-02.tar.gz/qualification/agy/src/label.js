/**
 * Formats a given identifier string into a standardized order label.
 *
 * @param {unknown} id - The order identifier string.
 * @returns {string} The formatted label, e.g. "ORDER:<id>".
 * @throws {TypeError} If id is not a string or is empty/whitespace only.
 */
function orderLabel(id) {
  if (typeof id !== 'string') {
    throw new TypeError('Order identifier must be a non-empty string');
  }

  const trimmed = id.trim();
  if (trimmed.length === 0) {
    throw new TypeError('Order identifier must be a non-empty string');
  }

  return `ORDER:${trimmed}`;
}

module.exports = {
  orderLabel,
};
