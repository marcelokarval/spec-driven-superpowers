const test = require('node:test');
const assert = require('node:assert/strict');
const { totalUnits } = require('../src/order.js');

test('order: Sum quantities of valid items', () => {
  assert.equal(totalUnits([{ quantity: 1 }]), 1);
  assert.equal(totalUnits([{ quantity: 50 }, { quantity: 30 }]), 80);
  assert.equal(totalUnits([{ quantity: 60 }, { quantity: 60 }]), 120);
  assert.equal(totalUnits([{ quantity: 100 }, { quantity: 100 }, { quantity: 50 }]), 250);
});

test('order: Return zero for empty item array', () => {
  assert.equal(totalUnits([]), 0);
});

test('order: Reject non-array input with TypeError', () => {
  assert.throws(() => totalUnits(null), { name: 'TypeError' });
  assert.throws(() => totalUnits(undefined), { name: 'TypeError' });
  assert.throws(() => totalUnits(123), { name: 'TypeError' });
  assert.throws(() => totalUnits('not-an-array'), { name: 'TypeError' });
  assert.throws(() => totalUnits({}), { name: 'TypeError' });
  assert.throws(() => totalUnits(true), { name: 'TypeError' });
});

test('order: Reject invalid items or quantities with TypeError atomically', () => {
  assert.throws(() => totalUnits([null]), { name: 'TypeError' });
  assert.throws(() => totalUnits([undefined]), { name: 'TypeError' });
  assert.throws(() => totalUnits(['not-object']), { name: 'TypeError' });
  assert.throws(() => totalUnits([123]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{}]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ id: 'no-quantity' }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: 0 }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: -1 }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: 101 }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: 1000 }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: '10' }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: 1.5 }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: NaN }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: Infinity }]), { name: 'TypeError' });
  assert.throws(() => totalUnits([{ quantity: 50 }, { quantity: 150 }]), { name: 'TypeError' });
});

test('order: Reads item.quantity exactly once to prevent getter mutation', () => {
  let readCount = 0;
  const itemWithGetter = {
    get quantity() {
      readCount += 1;
      return readCount === 1 ? 2 : Infinity;
    },
  };

  const result = totalUnits([itemWithGetter]);
  assert.equal(readCount, 1);
  assert.equal(result, 2);
});
