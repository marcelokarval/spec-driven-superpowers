const test = require('node:test'); const assert = require('node:assert/strict'); test('fixture ready', () => assert.ok(true));
