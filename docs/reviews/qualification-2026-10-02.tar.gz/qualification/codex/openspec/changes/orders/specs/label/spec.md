# label

## ADDED Requirements

### Requirement: Format independent identifier
O módulo label MUST fornecer o comportamento público abaixo por export nomeado CommonJS.

#### Scenario: Valid labels
- **WHEN** id é "abc", "  Ab-12 \n" ou "a b"
- **THEN** orderLabel(id) SHALL retornar respectivamente "ORDER:abc", "ORDER:Ab-12" ou "ORDER:a b", sem usar count ou order.

### Requirement: Reject invalid identifiers
O módulo label MUST fornecer o comportamento público abaixo por export nomeado CommonJS.

#### Scenario: Invalid labels
- **WHEN** id é "", somente espaços/tabulações/quebras de linha, número, booleano, null, undefined, objeto, array, Symbol(), bigint ou String encapsulada
- **THEN** orderLabel(id) SHALL lançar TypeError.

