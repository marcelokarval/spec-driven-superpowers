# Specification: Order Label Formatting

## Purpose
Format a standard textual order identifier string independently of item quantities or order calculations.

## ADDED Requirements

### Requirement: Order Label Generation
The `orderLabel` function SHALL format a given identifier string into `ORDER:<id-trimmed>`. It MUST trim leading and trailing whitespace and throw a `TypeError` if the argument is not a string or is empty after trimming.

#### Scenario: Format valid identifier with ORDER prefix
- **WHEN** the caller passes a non-empty string identifier
- **THEN** `orderLabel` returns the string prefixed with `ORDER:`

#### Scenario: Trim whitespace around identifier
- **WHEN** the caller passes a string identifier with surrounding whitespace
- **THEN** `orderLabel` trims whitespace before prefixing with `ORDER:`

#### Scenario: Reject non-string or blank identifier with TypeError
- **WHEN** the caller passes a non-string input, an empty string, or a string containing only whitespace
- **THEN** `orderLabel` throws a `TypeError`
