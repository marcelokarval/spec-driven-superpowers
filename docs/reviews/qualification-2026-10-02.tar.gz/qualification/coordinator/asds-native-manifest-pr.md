Selecting a second native harness skill directory currently collides with the existing `.asds/install-manifest.json`, even when every shared payload file is identical. This prevents the documented harness-specific installation from coexisting with the default Codex skill root.

Keep the default manifest byte-compatible and give other explicitly selected skill roots independent manifests. Payload conflicts still abort during preflight before any writes; no overwrite or legacy custom-manifest migration is introduced.

Validation: regression failed before the fix, then all 58 tests, syntax checks, package validation and whitespace checks passed. Independent read-only review approved 6690f56. Real user-scope previews confirm the default 90 planned files remain byte-identical and the second native root no longer conflicts. No second global installation was applied, and native Agy discovery is not claimed.
