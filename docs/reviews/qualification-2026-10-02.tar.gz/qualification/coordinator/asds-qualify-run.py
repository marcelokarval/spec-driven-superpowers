import pathlib,json,subprocess,sys,time,os,signal
BASE=pathlib.Path(__file__).resolve().parent
state=json.loads((BASE/'asds-qualification-state.json').read_text())
root=pathlib.Path(state['root']); evidence=root/'evidence';evidence.mkdir(exist_ok=True)
harness,label,prompt_file,*resume=sys.argv[1:]
prompt=pathlib.Path(prompt_file).read_text();cwd=pathlib.Path(os.environ.get('ASDS_PROBE_CWD',str(root/harness)))
if harness=='codex':
 cmd=['codex','exec','--sandbox','workspace-write']
 if os.environ.get('ASDS_ENTRY_PROBE'):
  cmd += ['-c', 'developer_instructions='+json.dumps('For ordinary conversation, answer directly without loading engineering workflows. For a new engineering request, use the available Accelerate skill to classify the action and preserve its context; non-trivial structured work goes to ASDS. An accepted ASDS workflow stays with its coordinator. Do not initialize OpenSpec without prior explicit authorization. Do not create a second plan or repeat already answered questions.')]
 if resume:cmd+=['resume','--json',resume[0],prompt]
 else:cmd+=['--json',prompt]
else:
 cmd=['agy','--dangerously-skip-permissions','--output-format','stream-json','--print-timeout','540s']
 if resume:cmd+=['--conversation',resume[0]]
 cmd+=['--print',prompt]
before=subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)
start=time.time();p=subprocess.Popen(cmd,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
try:out,err=p.communicate(timeout=570)
except subprocess.TimeoutExpired:
 os.killpg(p.pid,signal.SIGTERM);out,err=p.communicate(timeout=10)
def clean(x):
 if isinstance(x,dict):
  if x.get('type') in ('reasoning','thinking'):return None
  return {k:clean(v) for k,v in x.items() if k not in ('reasoning','thinking','aggregated_output','output','stderr')}
 if isinstance(x,list):return [clean(v) for v in x if not isinstance(v,dict) or v.get('type') not in ('thinking','reasoning')]
 return x
events=[]
for line in out.splitlines():
 try:events.append(clean(json.loads(line)))
 except ValueError:events.append({'type':'unparsed','text':line[:1000]})
r=dict(harness=harness,label=label,cwd=str(cwd),command=cmd,exitCode=p.returncode,duration=time.time()-start,events=events,stderr=err[-1500:],gitBefore=before,gitAfter=subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True))
(evidence/(harness+'-'+label+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['harness','label','exitCode','duration','stderr','gitAfter']} | {'messages':[e for e in events if e and (e.get('type')=='thread.started' or e.get('item',{}).get('type')=='agent_message' or e.get('event')=='result')]},ensure_ascii=False))
