import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {collectGitScope} from '../lib/git-scope.mjs';
import {loadTasks,validateChange} from '../lib/validation.mjs';
const root=JSON.parse(fs.readFileSync(new URL('./asds-qualification-state.json',import.meta.url))).root;
const stage=process.argv[2];
const ids=stage==='independent'?['0001','0003']:stage==='rework'?['0001']:['0002'];
for(const harness of (process.argv[3]?[process.argv[3]]:['codex','agy'])){
 const repo=path.join(root,harness),change=path.join(repo,'openspec/changes/orders');
 const git=(...a)=>{const r=spawnSync('git',['-c','core.hooksPath=/dev/null','-c','commit.gpgsign=false','-c','user.name=ASDS qualification','-c','user.email=fixture@example.invalid',...a],{cwd:repo,encoding:'utf8'});if(r.status)throw Error(r.stderr);return r.stdout.trim();};
 const run=command=>{if(!/^(npm test|node --test tests\/[a-z.]+(?: tests\/[a-z.]+)*)$/.test(command))throw Error('Unexpected verification command '+command);let [bin,...args]=command.split(' ');const r=spawnSync(bin,args,{cwd:repo,encoding:'utf8'});return {command,exitCode:r.status,revision:git('rev-parse','HEAD'),output:r.stdout+r.stderr};};
 const receiptsPath=path.join(root,'evidence',harness+'-receipts.json');
 const knownReceipts=fs.existsSync(receiptsPath)?JSON.parse(fs.readFileSync(receiptsPath)):{};
 const errors=validateChange(change,{receipts:knownReceipts});
 const unexpected=stage==='rework'?errors.filter(e=>!e.includes('0003')||!e.includes('contract')):errors;
 if(unexpected.length)throw Error(unexpected.join(';'));
 const tasks=loadTasks(change).filter(t=>ids.includes(t.id));
 const before=git('rev-parse','HEAD');
 const expected=tasks.flatMap(t=>t.write).sort();
 if(JSON.stringify(collectGitScope(repo,before).changedFiles)!==JSON.stringify(expected))throw Error('Unexpected worker scope');
 const deliveries=[];
 for(const task of tasks){let base=git('rev-parse','HEAD');git('add','--',...task.write);git('commit','-m',`pilot task ${task.id}`);deliveries.push({task:task.id,baseRevision:base,revision:git('rev-parse','HEAD'),contractRevision:task.contractRevision,changedFiles:task.write});}
 const branch=git('symbolic-ref','--short','HEAD'),integration=git('rev-parse','HEAD');
 for(const d of deliveries){git('checkout','--detach',d.revision);d.evidence=tasks.find(t=>t.id===d.task).verification.map(run);if(d.evidence.some(e=>e.exitCode!==0))throw Error('Delivery failed');}
 git('checkout',branch);if(git('status','--porcelain'))throw Error('Dirty after replay');
 const integrationEvidence=[run('npm test')];if(integrationEvidence[0].exitCode)throw Error('Integration failed');
 const result={harness,repo,change,stage,integrationBase:before,integrationRevision:integration,deliveries,integrationEvidence,scope:expected,contracts:loadTasks(change).map(t=>({id:t.id,contractRevision:t.contractRevision})),labelHash:createHash('sha256').update(fs.readFileSync(path.join(repo,'src/label.js'))).update(fs.readFileSync(path.join(repo,'tests/label.test.js'))).digest('hex'),reviewStatus:'pending'};
 fs.writeFileSync(path.join(root,'evidence',harness+'-'+stage+'-frozen.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({harness,stage,integrationRevision:integration,deliveries:deliveries.map(d=>({id:d.task,base:d.baseRevision,revision:d.revision})),tests:integrationEvidence[0].exitCode}));
}
