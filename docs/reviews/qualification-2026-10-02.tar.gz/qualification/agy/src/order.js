const { isPositiveCount } = require('./count.js');

/**
 * Calculates the total sum of units across items in an order.
 * Reuses isPositiveCount for quantity validation.
 * Reads quantity property exactly once per item to ensure the validated value is the summed value.
 * Rejects items with quantity > 100 with TypeError.
 * Allows accumulated total sum > 100 when each item is valid.
 *
 * @param {unknown} items - Array of { quantity } objects.
 * @returns {number} The total unit count, or 0 for an empty array.
 * @throws {TypeError} If items is not an array or if any item/quantity is invalid.
 */
function totalUnits(items) {
  if (!Array.isArray(items)) {
    throw new TypeError('Items must be an array');
  }

  if (items.length === 0) {
    return 0;
  }

  let total = 0;
  for (const item of items) {
    if (item === null || typeof item !== 'object' || !('quantity' in item)) {
      throw new TypeError('Each item must be an object containing a quantity property');
    }

    const quantity = item.quantity;
    if (!isPositiveCount(quantity)) {
      throw new TypeError('Item quantity must be a positive integer between 1 and 100 inclusive');
    }

    total += quantity;
  }

  return total;
}

module.exports = {
  totalUnits,
};
