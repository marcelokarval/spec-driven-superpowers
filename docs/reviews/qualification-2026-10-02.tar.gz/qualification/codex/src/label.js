function orderLabel(id) {
  if (typeof id !== 'string' || id.trim() === '') {
    throw new TypeError('Order id must be a non-empty string');
  }

  return `ORDER:${id.trim()}`;
}

module.exports = { orderLabel };
