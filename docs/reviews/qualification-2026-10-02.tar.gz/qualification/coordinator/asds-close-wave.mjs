import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {loadTasks,validateChange} from '../lib/validation.mjs';import {validateDelivery} from '../lib/contracts.mjs';
const root=JSON.parse(fs.readFileSync(new URL('./asds-qualification-state.json',import.meta.url))).root;
const stage=process.argv[2];
for(const h of ['codex','agy']){
 const file=path.join(root,'evidence',h+'-'+stage+'-frozen.json'),wave=JSON.parse(fs.readFileSync(file));
 const tasks=loadTasks(wave.change);const mapFile=path.join(root,'evidence',h+'-receipts.json');
 const receipts=fs.existsSync(mapFile)?JSON.parse(fs.readFileSync(mapFile)):{};
 if(stage==='rework'){const old=receipts['0003'];wave.deliveries.unshift({...old,task:'0003',contractRevision:tasks.find(t=>t.id==='0003').contractRevision});}
 const scopeFile=path.join(root,'evidence',h+'-'+stage+'-scope.json');fs.writeFileSync(scopeFile,JSON.stringify(wave.scope));
 for(const d of wave.deliveries){
  const task=tasks.find(t=>t.id===d.task);
  const integrationEvidence=task.verification.map(command=>{if(!/^(npm test|node --test tests\/[a-z.]+(?: tests\/[a-z.]+)*)$/.test(command))throw Error('Unexpected command');const [bin,...args]=command.split(' ');const r=spawnSync(bin,args,{cwd:wave.repo,encoding:'utf8'});if(r.status)throw Error(r.stdout+r.stderr);return {command,exitCode:r.status,revision:wave.integrationRevision,output:r.stdout+r.stderr};});
  const receipt={...d,status:'integrated',reviews:{spec:d.revision,quality:d.revision,independent:true},integrationRevision:wave.integrationRevision,integrationEvidence,integrationReviews:{spec:wave.integrationRevision,quality:wave.integrationRevision,independent:true}};
  const errors=validateDelivery(task,receipt);if(errors.length)throw Error(errors.join(';'));
  const rp=path.join(root,'evidence',h+'-'+stage+'-'+d.task+'-receipt.json');fs.writeFileSync(rp,JSON.stringify(receipt,null,2));
  receipts[d.task]=receipt;fs.writeFileSync(mapFile,JSON.stringify(receipts,null,2));
  const args=['scripts/validate.mjs','--change',wave.change,'--receipts',mapFile,'--delivery',rp,'--task',d.task,'--repo',wave.repo,'--base',d.baseRevision,'--delivery-revision',d.revision,'--integration-base',wave.integrationBase,'--integration-scope',scopeFile];
  const r=spawnSync(process.execPath,args,{encoding:'utf8'});if(r.status)throw Error(r.stdout+r.stderr);
  receipts[d.task]=receipt;
 }
 fs.writeFileSync(mapFile,JSON.stringify(receipts,null,2));
 const index=path.join(wave.change,'tasks.md');let text=fs.readFileSync(index,'utf8');
 for(const d of wave.deliveries)text=text.replace(new RegExp(`- \\[ \\] (\\[Task ${d.task}\\])`),'- [x] $1');
 fs.writeFileSync(index,text);const errors=validateChange(wave.change,{receipts});if(errors.length)throw Error(errors.join(';'));
 const r=spawnSync('git',['-c','core.hooksPath=/dev/null','-c','commit.gpgsign=false','-c','user.name=ASDS qualification','-c','user.email=fixture@example.invalid','commit','-am',`reconcile reviewed ${stage} tasks`],{cwd:wave.repo,encoding:'utf8'});if(r.status)throw Error(r.stdout+r.stderr);
 console.log(h+' scoped delivery/integration receipts validated; coordinator checkoff committed');
}
